var apiClass = function(){};
var dummyData = [{"policyNumber":"123456789","clientName":"Justin Kemp","requirementId":"1","requirement":"Incomplete Client Address","requirementStatus":"Open","requirementDetail":"Per US Patriots Act, require clients complete address - Please provide apartment number","userResponse":"50","lob":"Variable Annuities"},{"policyNumber":"123456789","clientName":"Justin Kemp","requirementId":"2","requirement":"NY Replacement form missing","requirementStatus":"Open","requirementDetail":"Download NY replacement form from eDox, fill the information and submit it","userResponse":"Information on replacement form provided","lob":"Variable Annuities"},{"policyNumber":"123456788","clientName":"Justin Kemp","requirementId":"1","requirement":"Representative Report Missing","requirementStatus":"Open","requirementDetail":"Complete all questions on Representatives Report. Please complete and Fax","userResponse":"Provided information on Representative Report","lob":"life"}];

apiClass.prototype.getURL = function(){
    var url = "https://chatbotdataservice.azurewebsites.net";
    return url;
};
apiClass.prototype.search = function(){
    var agentID = $("#agentID").val();
    var clientName = $("#client_name").val();
    var api = this.getURL()+"/getAgentData/"+agentID+"/"+clientName;
    this.getData(api);
};

apiClass.prototype.renderTable = function(element,dataset){
    $("#loader").hide();
    $(element).DataTable( {
        data: dataset,
        destroy: true,
        searching: false,
        columns: [
            { title: "Policy Number" },
            { title: "Client Name" },
            { title: "Requirement Id" },
            { title: "Requirement" },
            { title: "Requirement Status" },
            { title: "Requirement Detail"},
            { title: "User Response"},
            { data: "LOB"}
          ],
        columns: [
            { data: "policyNumber" },
            { data: "clientName" },
            { data: "requirementId" },
            { data: "requirement" },
            { data: "requirementStatus" },
            { data: "requirementDetail"},
            { data: "userResponse"},
            { data: "lob"}
          ]
    });
    $("#datatableContainer").show();
};
apiClass.prototype.getData = function(url){
    var _this = this;
    $.ajax({
        type: "GET",
        url: url,
        cache: false,
        success: function(data){
            _this.renderTable('#resultDataDisplay',data);
        },
        error:function(error){
            console.log(error,"Error! Now rendering dummy data!");
            _this.renderTable('#resultDataDisplay',dummyData);
        }
    }); 
};
apiClass.prototype.resetAllData = function(url){
    var _this = this;
    $.ajax({
        type: "GET",
        url: url,
        cache: false,
        success: function(data){
            $('#reset_success_modal').modal('show');
        },
        error:function(error){
            console.log(error,"Error!");
        }
    }); 
};
$(document).ready(function(){
    var appObj = new apiClass();
    $("#datatableContainer").hide();
    $("#searchBtn").on('click',function(){

        if($("#client_name").val()==""){
            $("#client_name").focus();
            $("#client_name").addClass("has-error");
        }else{
            $("#client_name").removeClass("has-error");
            $("#loader").show();
            appObj.search();
        }
    });

    $("#yes_reset_all").on("click",function(){
        var url = appObj.getURL()+"/resetAll"
        appObj.resetAllData(url);
        $('#resetmodal').modal('hide');
        $("#datatableContainer").hide();
        $("#client_name").val('');
    });
});